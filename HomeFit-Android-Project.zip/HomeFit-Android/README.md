# HomeFit Android app

A beginner-friendly five-day bodyweight workout checklist built with Kotlin and Jetpack Compose.

## GitHub Actions build

Push the complete project to the repository's `main` branch. Open **Actions**, select **Build HomeFit APK**, and wait for the workflow to finish successfully.

When it succeeds:
1. Open the successful workflow run.
2. Scroll to **Artifacts**.
3. Download **HomeFit-debug-apk**.
4. Extract the ZIP and install `app-debug.apk` on your Android phone.

## Required project structure

The root of the repository must contain `settings.gradle.kts`, `build.gradle.kts`, and `gradle.properties`. The Android module is in `app/`.
