package com.homefit.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

private data class WorkoutDay(val name: String, val focus: String, val exercises: List<String>)

private val workoutPlan = listOf(
    WorkoutDay("Monday", "Full body", listOf("March in place – 2 minutes", "Bodyweight squats – 2 × 10", "Wall push-ups – 2 × 10", "Glute bridges – 2 × 12", "Standing knee raises – 2 × 10 each side")),
    WorkoutDay("Tuesday", "Lower body & core", listOf("March in place – 2 minutes", "Chair squats – 2 × 10", "Standing calf raises – 2 × 12", "Bird-dog – 2 × 8 each side", "Knee-to-chest standing crunch – 2 × 10")),
    WorkoutDay("Wednesday", "Upper body & mobility", listOf("Arm circles – 30 seconds", "Wall push-ups – 2 × 10", "Shoulder blade squeezes – 2 × 12", "Standing side bends – 2 × 10 each side", "Cat-cow stretch – 8 repetitions")),
    WorkoutDay("Thursday", "Active recovery", listOf("Easy indoor walk – 5 minutes", "Gentle neck and shoulder mobility – 2 minutes", "Standing hamstring stretch – 20 seconds each side", "Calf stretch – 20 seconds each side", "Deep breathing – 2 minutes")),
    WorkoutDay("Friday", "Full body", listOf("March in place – 2 minutes", "Chair squats – 2 × 10", "Wall push-ups – 2 × 10", "Glute bridges – 2 × 12", "Bird-dog – 2 × 8 each side"))
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { HomeFitApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun HomeFitApp() {
    var selectedDay by rememberSaveable { mutableIntStateOf(0) }
    val completed = rememberSaveable { mutableStateListOf<String>() }
    val day = workoutPlan[selectedDay]
    val doneToday = day.exercises.count { "$selectedDay:$it" in completed }

    MaterialTheme(colorScheme = lightColorScheme()) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("HomeFit", fontWeight = FontWeight.Bold)
                            Text("Your 5-day home workout", style = MaterialTheme.typography.labelSmall)
                        }
                    }
                )
            }
        ) { padding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(16.dp)
            ) {
                Text("Choose your day", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    workoutPlan.forEachIndexed { index, item ->
                        FilterChip(
                            selected = selectedDay == index,
                            onClick = { selectedDay = index },
                            label = { Text(item.name.take(3)) }
                        )
                    }
                }
                Spacer(Modifier.height(18.dp))
                Text(day.name, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                Text(day.focus, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.height(12.dp))
                LinearProgressIndicator(
                    progress = { if (day.exercises.isEmpty()) 0f else doneToday.toFloat() / day.exercises.size },
                    modifier = Modifier.fillMaxWidth()
                )
                Text("$doneToday of ${day.exercises.size} exercises completed", style = MaterialTheme.typography.bodySmall)
                Spacer(Modifier.height(12.dp))
                Text("Workout checklist", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    itemsIndexed(day.exercises) { _, exercise ->
                        val key = "$selectedDay:$exercise"
                        Card(modifier = Modifier.fillMaxWidth()) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Checkbox(
                                    checked = key in completed,
                                    onCheckedChange = { checked ->
                                        if (checked && key !in completed) completed.add(key)
                                        if (!checked) completed.remove(key)
                                    }
                                )
                                Text(exercise, modifier = Modifier.weight(1f))
                            }
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
                OutlinedButton(
                    onClick = { day.exercises.forEach { completed.remove("$selectedDay:$it") } },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Reset this day's checklist")
                }
                Text(
                    "Start gently. Stop if you feel pain, dizziness, chest discomfort or unusual breathlessness.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.error,
                    modifier = Modifier.padding(top = 10.dp)
                )
            }
        }
    }
}
